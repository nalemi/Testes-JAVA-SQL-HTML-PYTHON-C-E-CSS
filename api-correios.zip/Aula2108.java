/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula21.pkg08;


public class Aula2108 { /*metodos/*/

    public static int valor(int a,int b){
        int x=a+b;
        return x;
    };
    
    public static void main(String[] args) {
        System.out.println(valor(15,29));  
        System.out.println(valor(10,50));  
    }
    
}
